declare module "@salesforce/apex/LogEntryEventStreamController.isEnabled" {
  export default function isEnabled(): Promise<any>;
}
declare module "@salesforce/apex/LogEntryEventStreamController.getDatatableDisplayFields" {
  export default function getDatatableDisplayFields(): Promise<any>;
}
