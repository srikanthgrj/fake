declare module "@salesforce/apex/RelatedLogEntriesController.getQueryResult" {
  export default function getQueryResult(param: {recordId: any, fieldSetName: any, rowLimit: any, rowOffset: any, sortByFieldName: any, sortDirection: any, search: any}): Promise<any>;
}
