declare module "@salesforce/apex/LoggerSettingsController.canUserModifyLoggerSettings" {
  export default function canUserModifyLoggerSettings(): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.getPicklistOptions" {
  export default function getPicklistOptions(): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.getRecords" {
  export default function getRecords(): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.createRecord" {
  export default function createRecord(): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.saveRecord" {
  export default function saveRecord(param: {settingsRecord: any}): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.deleteRecord" {
  export default function deleteRecord(param: {settingsRecord: any}): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.getOrganization" {
  export default function getOrganization(): Promise<any>;
}
declare module "@salesforce/apex/LoggerSettingsController.searchForSetupOwner" {
  export default function searchForSetupOwner(param: {setupOwnerType: any, searchTerm: any}): Promise<any>;
}
