declare module "@salesforce/apex/LoggerHomeHeaderController.getEnvironmentDetails" {
  export default function getEnvironmentDetails(): Promise<any>;
}
