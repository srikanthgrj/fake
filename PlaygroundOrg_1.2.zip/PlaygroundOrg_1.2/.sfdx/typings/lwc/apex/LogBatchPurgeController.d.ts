declare module "@salesforce/apex/LogBatchPurgeController.canUserRunLogBatchPurger" {
  export default function canUserRunLogBatchPurger(): Promise<any>;
}
declare module "@salesforce/apex/LogBatchPurgeController.getMetrics" {
  export default function getMetrics(param: {dateFilterOption: any}): Promise<any>;
}
declare module "@salesforce/apex/LogBatchPurgeController.getPurgeActionOptions" {
  export default function getPurgeActionOptions(): Promise<any>;
}
declare module "@salesforce/apex/LogBatchPurgeController.getBatchPurgeJobRecords" {
  export default function getBatchPurgeJobRecords(): Promise<any>;
}
declare module "@salesforce/apex/LogBatchPurgeController.runBatchPurge" {
  export default function runBatchPurge(): Promise<any>;
}
