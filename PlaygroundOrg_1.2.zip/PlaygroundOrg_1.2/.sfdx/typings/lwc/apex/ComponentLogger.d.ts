declare module "@salesforce/apex/ComponentLogger.getSettings" {
  export default function getSettings(): Promise<any>;
}
declare module "@salesforce/apex/ComponentLogger.saveComponentLogEntries" {
  export default function saveComponentLogEntries(param: {componentLogEntries: any, saveMethodName: any}): Promise<any>;
}
