declare module "@salesforce/apex/LogEntryMetadataViewerController.getMetadata" {
  export default function getMetadata(param: {recordId: any, sourceMetadata: any}): Promise<any>;
}
