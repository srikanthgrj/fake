declare module "@salesforce/apex/LogViewerController.getLog" {
  export default function getLog(param: {logId: any}): Promise<any>;
}
