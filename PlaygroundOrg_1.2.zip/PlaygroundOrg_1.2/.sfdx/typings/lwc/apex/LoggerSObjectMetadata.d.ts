declare module "@salesforce/apex/LoggerSObjectMetadata.getSchemaForName" {
  export default function getSchemaForName(param: {sobjectApiName: any}): Promise<any>;
}
