declare module "@salesforce/resourceUrl/LoggerResources" {
    var LoggerResources: string;
    export default LoggerResources;
}